package com.phishing.dashboard.service;

import com.phishing.dashboard.model.AnalysisResult;
import org.springframework.stereotype.Service;

@Service
public class PhishingAnalyzerService {
    
    public AnalysisResult analyze(String emailContent) {
        int score = 0;
        StringBuilder report = new StringBuilder();
        
        String lowerContent = emailContent.toLowerCase();
        
        // RULE 1: Suspicious Sender (25 max)
        if (lowerContent.contains("paypal") && (lowerContent.contains("security") || lowerContent.contains("support"))) {
            score += 25;
            report.append("⚠️ Suspicious sender (PayPal-like)\n");
        }
        if (lowerContent.contains("bank") && lowerContent.contains("support")) {
            score += 20;
            report.append("⚠️ Suspicious bank sender\n");
        }
        
        // RULE 2: Malicious URLs (30 max)
        if (lowerContent.contains("bit.ly") || lowerContent.contains("tinyurl") || lowerContent.contains("t.co")) {
            score += 30;
            report.append("🔗 Suspicious URL shortener\n");
        }
        if (lowerContent.contains("http") && !lowerContent.contains("https")) {
            score += 15;
            report.append("🔒 Insecure HTTP detected\n");
        }
        
        // RULE 3: Urgent Language (20 max)
        String[] urgentWords = {"urgent", "immediate", "verify now", "suspended", "locked"};
        for (String word : urgentWords) {
            if (lowerContent.contains(word)) {
                score += 20;
                report.append("🚨 Panic phrase: '").append(word).append("'\n");
                break;
            }
        }
        
        // RULE 4: Dangerous Attachments (25 max)
        String[] dangerousExt = {".exe", ".zip", ".scr", ".bat"};
        for (String ext : dangerousExt) {
            if (lowerContent.contains(ext)) {
                score += 25;
                report.append("📎 Dangerous file: ").append(ext).append("\n");
                break;
            }
        }
        
        // CAP SCORE AT 100
        score = Math.min(100, score);
        
        // Risk Classification
        String riskLevel;
        if (score >= 90) riskLevel = "CRITICAL";
        else if (score >= 70) riskLevel = "HIGH";
        else if (score >= 50) riskLevel = "MEDIUM";
        else if (score >= 25) riskLevel = "LOW";
        else riskLevel = "SAFE";
        
        boolean isSafe = score < 25;
        
        if (score == 0) {
            report.append("✅ No phishing indicators");
        }
        
        report.append("\n📊 Score: ").append(score).append("/100");
        
        return new AnalysisResult(score, riskLevel, report.toString(), isSafe);
    }
}