package com.phishing.dashboard.model;

public class AnalysisResult {

    private int score;
    private String riskLevel;
    private String report;
    private boolean isSafe;

    public AnalysisResult(int score, String riskLevel, String report, boolean isSafe) {
        this.score = score;
        this.riskLevel = riskLevel;
        this.report = report;
        this.isSafe = isSafe;
    }

    public int getScore() { return score; }
    public String getRiskLevel() { return riskLevel; }
    public String getReport() { return report; }
    public boolean isSafe() { return isSafe; }
}