package com.phishing.dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhishingDashboardApplication {
    public static void main(String[] args) {
        SpringApplication.run(PhishingDashboardApplication.class, args);
        System.out.println("\n🚀 Phishing Detection Dashboard Started!");
        System.out.println("🌐 Open: http://localhost:3000");
        System.out.println("📱 API: POST /api/phishing/analyze\n");
    }
}