package com.phishing.dashboard.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.phishing.dashboard.model.User;

@Controller
public class AuthController {

    // Temporary user storage
    private List<User> users = new ArrayList<>();


    // Open Register Page
    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    // Register User
    @PostMapping("/register")
    public String registerUser(@RequestParam String username,
                               @RequestParam String password) {

        users.add(new User(username, password));

        return "redirect:/login";
    }

    // Open Login Page
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    // Login Check
    @PostMapping("/login")
    public String loginUser(@RequestParam String username,
                            @RequestParam String password,
                            Model model) {

        for(User user : users) {

            if(user.getUsername().equals(username)
               && user.getPassword().equals(password)) {

                return "dashboard";
            }
        }

        model.addAttribute("error", "Invalid Username or Password");

        return "login";
    }
}