package com.phishing.dashboard.controller;

import com.phishing.dashboard.model.AnalysisResult;
import com.phishing.dashboard.model.EmailRequest;
import com.phishing.dashboard.service.PhishingAnalyzerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/phishing")
@CrossOrigin(origins = "*")
public class PhishingDetectionController {
    
    @Autowired
    private PhishingAnalyzerService analyzerService;
    
    @PostMapping("/analyze")
public AnalysisResult analyze(@RequestBody EmailRequest request) {
    try {
        if (request == null || request.getContent() == null || request.getContent().trim().isEmpty()) {
            return new AnalysisResult(0, "ERROR", "Please provide email content", false);
        }

        return analyzerService.analyze(request.getContent());

    } catch (Exception e) {
        return new AnalysisResult(0, "ERROR", "Server error", false);
    }
}
    
    @GetMapping("/health")
    public String healthCheck() {
        return "{\"status\":\"healthy\",\"service\":\"Phishing Detection v1.0\",\"timestamp\":\"" + 
               java.time.LocalDateTime.now() + "\"}";
    }
}