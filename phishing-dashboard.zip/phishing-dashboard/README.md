# 🚀 Phishing Detection Dashboard

[![Demo](https://img.shields.io/badge/Live_Demo-000?style=for-the-badge&logo=vercel&logoColor=white)](http://localhost:3000)

## ✨ Features
- 🔍 **Real-time phishing analysis** (5+ rules)
- 📊 **Risk scoring** 0-100 with 5 levels
- 🎨 **Glassmorphism UI** - Responsive design
- ⚡ **Zero dependencies** - Runs anywhere
- 🐳 **Docker ready** - One-click deploy

## 🛠️ Quick Start
```bash
mvn clean package
java -jar target/dashboard-1.0.0.jar
# or
docker build -t phishing . && docker run -p 3000:3000 phishing